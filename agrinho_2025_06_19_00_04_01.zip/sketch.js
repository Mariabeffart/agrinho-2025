let cols;
let rows;
let cellSize = 60;

let terreno = []; // Matriz que representará nosso terreno de cultivo

let dinheiro = 0; // Variável para armazenar a pontuação do jogador
const META_VITORIA = 500; // Pontuação necessária para vencer o jogo

let jogoTerminado = false; // Flag para controlar se o jogo acabou

// Definições de cores
const COR_TERRA = [139, 69, 19];
const COR_GRAMA = [124, 252, 0];
const COR_PLANTA_ORGANICA = [34, 139, 34];
const COR_PLANTA_TECNOLOGICA = [0, 191, 255];
const COR_PLANTA_MADURA = [255, 215, 0]; // Cor para planta madura (ouro)
const COR_MENSAGEM_VITORIA = [0, 100, 0]; // Verde escuro para a mensagem

// Valores de colheita
const VALOR_ORGANICA = 10;
const VALOR_TECNOLOGICA = 25;

let intervaloCrescimento; // Variável para armazenar o ID do intervalo de crescimento

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(COR_GRAMA);

  cols = floor(width / cellSize);
  rows = floor(height / cellSize);

  iniciarJogo(); // Chama a função para configurar o estado inicial do jogo
}

function draw() {
  drawTerreno();
  displayDinheiro(); // Mostra o dinheiro na tela

  if (jogoTerminado) {
    displayMensagemVitoria(); // Mostra a mensagem de vitória se o jogo terminou
  }
}

// Função para iniciar ou reiniciar o jogo
function iniciarJogo() {
  dinheiro = 0;
  jogoTerminado = false;

  // Limpa qualquer intervalo de crescimento anterior para evitar múltiplos
  if (intervaloCrescimento) {
    clearInterval(intervaloCrescimento);
  }

  // Inicializa o terreno com células vazias
  for (let i = 0; i < cols; i++) {
    terreno[i] = [];
    for (let j = 0; j < rows; j++) {
      terreno[i][j] = {
        tipo: 0, // 0: vazia, 1: orgânica, 2: tecnológica
        crescimento: 0 // 0 a 100 (ou qualquer outro valor para representar o progresso)
      };
    }
  }

  // Define um intervalo para o "crescimento" das plantas
  intervaloCrescimento = setInterval(crescerPlantas, 1000);
}


function drawTerreno() {
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let x = i * cellSize;
      let y = j * cellSize;

      stroke(50);
      strokeWeight(1);
      fill(COR_TERRA);
      rect(x, y, cellSize, cellSize);

      let celula = terreno[i][j];

      if (celula.tipo === 1) { // Planta Orgânica
        drawPlantaOrganica(x, y, celula.crescimento);
      } else if (celula.tipo === 2) { // Planta Tecnológica
        drawPlantaTecnologica(x, y, celula.crescimento);
      }
    }
  }
}

// Desenha planta orgânica, agora com base no crescimento
function drawPlantaOrganica(x, y, crescimento) {
  let tamanho = map(crescimento, 0, 100, cellSize * 0.2, cellSize * 0.8);
  let cor = COR_PLANTA_ORGANICA;

  // Se a planta estiver totalmente crescida, muda a cor para indicar que está pronta para colheita
  if (crescimento >= 100) {
    cor = COR_PLANTA_MADURA;
  }

  fill(cor);
  noStroke();
  ellipse(x + cellSize / 2, y + cellSize / 2, tamanho * 0.7, tamanho);
  // Desenha uma folha menor se a planta for pequena
  if (crescimento > 50) {
    triangle(x + cellSize / 2, y + cellSize / 4,
             x + cellSize * 0.7, y + cellSize * 0.2,
             x + cellSize * 0.8, y + cellSize * 0.5);
  }
}

// Desenha planta tecnológica, agora com base no crescimento
function drawPlantaTecnologica(x, y, crescimento) {
  let tamanho = map(crescimento, 0, 100, cellSize * 0.3, cellSize * 0.7);
  let cor = COR_PLANTA_TECNOLOGICA;

  if (crescimento >= 100) {
    cor = COR_PLANTA_MADURA;
  }

  fill(cor);
  noStroke();
  rect(x + (cellSize - tamanho) / 2, y + (cellSize - tamanho) / 2, tamanho, tamanho);
  // Desenha um pequeno "brilho" ou "circuito"
  fill(255, 255, 0); // Amarelo
  ellipse(x + cellSize / 2, y + cellSize / 2, tamanho * 0.3, tamanho * 0.3);
}

// Função para exibir o dinheiro na tela
function displayDinheiro() {
  fill(255); // Cor branca para o texto
  textSize(24);
  textAlign(LEFT, TOP);
  text(`Dinheiro: $${dinheiro}`, 10, 10); // Mostra o valor na parte superior esquerda
  // Exibe a meta
  textAlign(RIGHT, TOP);
  text(`Meta: $${META_VITORIA}`, width - 10, 10);
}

// Função que faz as plantas crescerem
function crescerPlantas() {
  if (jogoTerminado) return; // Não cresce plantas se o jogo terminou

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let celula = terreno[i][j];
      if (celula.tipo !== 0 && celula.crescimento < 100) {
        let velocidadeCrescimento = 5;
        if (celula.tipo === 1) { // Orgânica
            velocidadeCrescimento = 3;
        } else if (celula.tipo === 2) { // Tecnológica
            velocidadeCrescimento = 7;
        }
        celula.crescimento += velocidadeCrescimento;
        if (celula.crescimento > 100) {
          celula.crescimento = 100; // Limita o crescimento a 100
        }
      }
    }
  }
}

// Lida com cliques do mouse: plantar ou colher ou reiniciar
function mousePressed() {
  if (jogoTerminado) {
    iniciarJogo(); // Se o jogo terminou, clique para reiniciar
    return;
  }

  let col = floor(mouseX / cellSize);
  let row = floor(mouseY / cellSize);

  if (col >= 0 && col < cols && row >= 0 && row < rows) {
    let celula = terreno[col][row];

    if (celula.tipo === 0) {
      celula.tipo = 1; // Começa como planta orgânica
      celula.crescimento = 0;
    } else if (celula.tipo !== 0 && celula.crescimento >= 100) {
      colherPlanta(col, row);
    } else if (celula.tipo === 1) {
        celula.tipo = 2; // Transforma em tecnológica
        celula.crescimento = 0;
    } else if (celula.tipo === 2) {
        celula.tipo = 0; // Esvazia
        celula.crescimento = 0;
    }
  }
}

// Função para colher uma planta
function colherPlanta(col, row) {
  let celula = terreno[col][row];
  if (celula.tipo === 1) { // Orgânica
    dinheiro += VALOR_ORGANICA;
  } else if (celula.tipo === 2) { // Tecnológica
    dinheiro += VALOR_TECNOLOGICA;
  }
  // Após colher, a célula volta a ficar vazia
  celula.tipo = 0;
  celula.crescimento = 0;

  // Verifica se o jogador atingiu a meta após colher
  if (dinheiro >= META_VITORIA) {
    jogoTerminado = true;
    clearInterval(intervaloCrescimento); // Para o crescimento das plantas
  }
}

// Função para exibir a mensagem de vitória
function displayMensagemVitoria() {
  fill(COR_MENSAGEM_VITORIA);
  rectMode(CENTER); // Desenha o retângulo a partir do centro
  rect(width / 2, height / 2, 400, 200, 20); // Retângulo arredondado no centro

  fill(255); // Texto branco
  textSize(32);
  textAlign(CENTER, CENTER);
  text("VOCÊ VENCEU!", width / 2, height / 2 - 30);
  textSize(20);
  text("Parabéns! Você alcançou sua meta!", width / 2, height / 2 + 10);
  textSize(18);
  text("Clique para jogar novamente", width / 2, height / 2 + 50);
  rectMode(CORNER); // Volta o modo de retângulo ao normal
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  cols = floor(width / cellSize);
  rows = floor(height / cellSize);
  // Nota: Em um jogo mais complexo, o redimensionamento precisaria reposicionar elementos.
}